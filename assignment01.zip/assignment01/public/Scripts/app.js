// IIFE -- Immediately  Invoked Fuction Expression
(function(){

    function Start()
    {
        console.log("App Started...")
    }

    window.addEventListener("load",Start);
    
})();